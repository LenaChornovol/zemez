<?php

namespace PrestaShop\PrestaShop\Core\Product\Search;

interface FacetsRendererInterface
{
}
